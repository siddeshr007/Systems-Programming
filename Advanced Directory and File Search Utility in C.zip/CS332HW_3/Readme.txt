Execute the  Makefile 

1) make 

now run the file 

./search 

./search -s 1000

./search -s 1000 -e "wc -l"

./search -s 1000 -e "ls -l"


./search -S 

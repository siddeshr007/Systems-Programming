#include <stdio.h>

int UABNumber () {
    int n2;
    int sum =  0;
    scanf("%d", &n2);
    for (int i = 1; i < n2; i++ ) {
        if (n2 % i == 0) {
            sum += i;
                 
        } 
    }

    if (n2 == sum){
        return 1;
    
    
    }
    else{
        return 0;

    }
}
int main (){
    int x = UABNumber();
        printf("%d", x);
}
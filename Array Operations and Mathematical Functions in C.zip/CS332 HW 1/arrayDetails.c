#include <stdio.h>

int *arrayDetails (int arr[], int size){
    int i;
    int minimum = 9999;
    int maximum = -9999;
    int sum = 0;
    int minimumIndex = 0;
    int maximumIndex = 0;
    
    int outputArr [6];
    outputArr[0] = size;
    for (i = 0; i < size; i++) {
        if (maximum < arr[i] ) {
            maximum = arr[i];
            maximumIndex = i;
    
        }
        if (minimum > arr[i]) {
            minimum = arr[i];
            minimumIndex = i;
            
        }
        sum += arr[i];
    }
    float mean = sum / size;
    outputArr[1] = minimum;
    outputArr[2] = minimumIndex;
    outputArr[3] = mean;
    outputArr[4] = maximum;
    outputArr[5] = maximumIndex;
    //for (int i = 0; i < 6; i++ ){
        //printf ("%d ", outputArr[i]);
    //}
return outputArr; 
}

int main (void){
    int arr[] = {-8, -23, 18, 103, 0, 1, -4, 631, 3, -41, 5};
    int *result = arrayDetails(arr, 11);
    for (int i = 0; i < 6; i++ ){
        printf ("%d ", result[i]);
    } 
    return 0;
}
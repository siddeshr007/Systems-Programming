#include <stdio.h>

void introTo332532(int n2) {
    int i;
    int flag = 0;
    for (i = 2; i <= n2 / 2; i++) {
        if (n2 % i == 0) {
            flag = 1;
            break;
        }
    }
    if (n2 % 3 == 0 && n2 % 7 == 0) {
        printf("CS");
    } else if (n2 % 7 == 0) {
        printf("UAB");
    } else if (n2 % 3 == 0) {
        printf("CS");
    } else if (flag == 0) {
        printf("Go Blazers");
    } else if (n2 % 3 == 0 && n2 % 5 == 0){
      printf("UAB CS 332&532");
    } else {
        printf("%d", n2*n2*n2);
    }
}

int main() {
    introTo332532(30);
    return 0;
}
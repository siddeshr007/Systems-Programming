#include <stdio.h>

void reverseNum(int n3) {
    int reversed = 0;
    while (n3 > 0) {
        reversed = reversed * 10 + n3 % 10;
        n3 /= 10;
    }
    printf("%d", reversed);
}

int main (){
    int n3 = 1234;
    reverseNum(n3);
    return 0;
}
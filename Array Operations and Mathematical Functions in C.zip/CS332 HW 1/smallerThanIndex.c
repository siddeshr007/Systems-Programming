#include <stdio.h>

int smallerThanIndex(int listOfNumbers[], int n) {
    int count = 0;
    for (int i = 0; i < n; i++) {
        if (listOfNumbers[i] < i) count++;
    }
    return count;
}
int main (){
    int listOfNumbers[] = {10,20,1,2,30};
    int n = sizeof(listOfNumbers)/sizeof(listOfNumbers[0]);
    int x = smallerThanIndex(listOfNumbers,n);
    printf("%d", x);
    return 0;
}






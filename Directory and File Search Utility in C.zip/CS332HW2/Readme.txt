Execute the  Makefile 

1) make 

now run the file 

./search 

./search -s 1000

./search -S 


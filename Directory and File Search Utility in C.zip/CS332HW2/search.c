#include <unistd.h>
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <time.h>

typedef void fun1(char loc[300], int root);
typedef void fun2(char loc[300],int bytes,int root);

void func1(char loc[300], int root, fun1 *f)
{
    f(loc, root);
}
void func2(char loc[300],int bytes, int root, fun2 *f)
{
    f(loc,bytes,root);
}
int main(int argc, char const *argv[])
{

    void displayDirAndFileWithSize(char loc[300], int root);
    void displayDirAndFiles(char loc[300], int root);
    void displayDirAndFileswithBytes(char loc[300], int bytes, int root);

    char loc[300] = ".";
    char ext[100];
    int flag1 = 0;
    int flag2 = 0;
    int flag3 = 0;
    int size = 0;
    int level = 0;
    int k = 1;
    while (k < argc)
    {
        if (strcmp(argv[k], "-S") == 0)
        {
            flag1 = 1;
        }
        else if (strcmp(argv[k], "-s") == 0)
        {
            flag2 = 1;
            size = atoi(argv[++k]);
        }
        else if (strcmp(argv[k], "-f") == 0)
        {
            flag3 = 1;
            strcpy(ext, argv[++k]);
            level = atoi(argv[++k]);
        }
        else
        {
            strcpy(loc, argv[k]);
        }

        k++;
    }
    if (flag1 == 0)
    {

        if (flag2 != 0 && flag3 != 0)
        {
            
        }
        else if (flag2 != 0)
        {
            printf("display List \n");
            func2(loc,size,0,displayDirAndFileswithBytes);
        }
        else if (flag3 != 0)
        {
        }
        else
        {
            func1(loc, 0, displayDirAndFiles);
        }
    }
    else
    {
            func1(loc, 0, displayDirAndFileWithSize);
        
    }

    return 0;
}

void displayDirAndFiles(char loc[300], int root)
{
    int i;
    char base[300];
    struct dirent *bp;
    DIR *d = opendir(loc);
    if (d)
    {
        while ((bp = readdir(d)) != NULL)
        {
            if (strcmp(bp->d_name, "..") != 0 && strcmp(bp->d_name, ".") != 0)
            {
                for (int i = 0; i < root; i++)
                {
                    printf(" ");
                }

                printf("%s\n", bp->d_name);
                if (bp->d_type == 4)
                {
                    strcpy(base, loc);
                    strcat(base, "/");
                    strcat(base, bp->d_name);
                    displayDirAndFiles(base, root + 2);
                }
            }
        }
    }
}

void displayDirAndFileswithBytes(char loc[300], int size, int root)
{
    int i;
    char base[300];
    struct dirent *bp;
    FILE *fp;
    int bytes;
    DIR *d = opendir(loc);
    if (d)
    {
        while ((bp = readdir(d)) != NULL)
        {
            if (strcmp(bp->d_name, "..") != 0 && strcmp(bp->d_name, ".") != 0)
            {
                for (int i = 0; i < root; i++)
                {
                    printf(" ");
                }
                fp =  fopen(bp->d_name,"r");
                if(fp != NULL)
                 {
                  fseek(fp,0,2);
                  bytes = ftell(fp);
                 }
                 if(bytes >= size)
                    printf("%s\n", bp->d_name);
                if (bp->d_type == 4)
                {
                    strcpy(base, loc);
                    strcat(base, "/");
                    strcat(base, bp->d_name);
                    displayDirAndFileswithBytes(base, size,root + 2);
                }
            }
        }
    }
}


void displayDirAndFileWithSize(char loc[300], int root)
{
    int i;
    char base[300];
    struct dirent *bp;
    char ch;
    FILE *fp;
    int size = 0;
    struct stat fs;
    char t[100] = "";
    int r;
    DIR *d = opendir(loc);
    if (d)
    {
        while ((bp = readdir(d)) != NULL)
        {
            if (strcmp(bp->d_name, "..") != 0 && strcmp(bp->d_name, ".") != 0)
            {
                for (int i = 0; i < root; i++)
                {
                    printf(" ");
                }

                printf("%s\n", bp->d_name);

                fp = fopen(bp->d_name, "r");
                if (fp != NULL)
                {
                    fseek(fp, 0, 2);
                    size = ftell(fp);
                    printf("(%d)", size);
                    r = stat(bp->d_name, &fs);
                    if (r == -1)
                    {
                    }
                    else
                    {
                        if (S_ISREG(fs.st_mode))
                        {
                            if (fs.st_mode & S_IRUSR)
                                printf("(Read ");
                            else
                                printf("(");
                            if (fs.st_mode & S_IWUSR)
                                printf("write ");
                            if (fs.st_mode & S_IXUSR)
                                printf("Execute)");
                            else
                                printf(")");
                        }
                        strftime(t, 100, "%d/%m/%Y %H:%M:%S", localtime(&fs.st_mtime));
                        printf("(%s)", t);
                    }
                    printf("\n");
                }
                strcpy(base, loc);
                strcat(base, "/");
                strcat(base, bp->d_name);
                displayDirAndFileWithSize(base, root + 2);
            }
        }
    }
}

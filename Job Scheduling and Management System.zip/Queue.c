
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>
#include "Queue.h"

j_details CreateJob(char *cmd, int jid)
{
    j_details jd;
    jd.j_id = jid;
    jd.command = copy(cmd);
    jd.status = "waiting";
    jd.exit_status = -1;
    jd.start_time = jd.end_time = NULL;
    sprintf(jd.fileoutput, "%d.out", jd.j_id);
    sprintf(jd.fileerr, "%d.err", jd.j_id);
    return jd;
}

void viewJobs(j_details *jd,int count_jobs,char *mode)
{
    int k;
    if (jd != NULL && count_jobs != 0)
    {
        if (strcmp(mode, "showjobs") == 0)
        {
            for (k = 0; k < count_jobs; ++k)
            {
                if (strcmp(jd[k].status, "complete") != 0)
                    printf("Job ID: %d\n"
                           "Command: %s\n"
                           "Status: %s\n\n",
                           jd[k].j_id,
                           jd[k].command,
                           jd[k].status);
            }
        }
        else if (strcmp(mode, "submithistory") == 0)
        {
            for (k = 0; k < count_jobs; k++)
            {
                if (strcmp(jd[k].status, "complete") == 0)
                    printf("Job ID: %d\n"
                           "Thread ID: %ld\n"
                           "Command: %s\n"
                           "Exit Status: %d\n"
                           "Start Time: %s\n"
                           "Stop Time: %s\n\n",
                           jd[k].j_id,
                           jd[k].pid,
                           jd[k].command,
                           jd[k].exit_status,
                           jd[k].start_time,
                           jd[k].end_time);
            }
        }
    }
}


/*
char *copy(char *s)
{
    int j, c;
    char *cp;

    j = -1;
    cp = malloc(sizeof(char) * strlen(s));
    while ((c = s[++j]) != '\0')
     {
        cp[j] = c;
     }
    cp[j] = '\0';

    return cp;
}
*/
job_q *init_q(int n)
{
    job_q *jq = malloc(sizeof(job_q));
    jq->q_size = n;
    jq->jobbuffer = malloc(sizeof(j_details *) * n);
    jq->start_index = 0;
    jq->end_index = 0;
    jq->q_count = 0;

    return jq;
}
int insert_q(job_q *jq, j_details *jd)

{
    if ((jq == NULL) || (jq->q_count == jq->q_size))
        return -1;

    jq->jobbuffer[jq->end_index % jq->q_size] = jd;
    jq->end_index = (jq->end_index + 1) % jq->q_size;
    ++jq->q_count;

    return jq->q_count;
}

j_details *delete_q(job_q *jq)
{
    if ((jq == NULL) || (jq->q_count == 0))
        return (j_details *)-1;

    j_details *jd = jq->jobbuffer[jq->start_index];
    jq->start_index = (jq->start_index + 1) % jq->q_size;
    --jq->q_count;

    return jd;
}

void destroy_q(job_q *jq)
{
    free(jq->jobbuffer);
    free(jq);
}

int get_l(char *st, int n)
{
    int j, ch;
    for (j = 0; j < n - 1 && (ch = getchar()) != '\n'; ++j)
    {
        if (ch == EOF)
            return -1;
        st[j] = ch;
    }
    st[j] = '\0';
    return j;
}
int isSpace(char ch)
{
    return (ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r' || ch == '\x0b' || ch == '\x0c');
}

char *l_s(char *st)
{
    int k = 0;
    while (isSpace(st[k]))
    {
        k++;
    }
    return st + k;
}

char* copy(char *st)
{
    int k, ch;
    char *cp;
    k = -1;
    cp = malloc(sizeof(char) * strlen(st));
    while ((ch = st[++k]) != '\0')
        cp[k] = ch;
    cp[k] = '\0';

    return cp;
}

char *copynewline(char *st)
{
    int k, ch;
    char *cp;
    k = -1;
    cp = malloc(sizeof(char) * strlen(st));
    while ((ch = st[++k]) != '\0' && ch != '\n')
    {
        cp[k] = ch;
    }
    cp[k] = '\0';
    return cp;
}


char *datetime_current()
{
    time_t tm = time(NULL);
    return copynewline(ctime(&tm));
}

char **arguments(char *ln)
{
    char *cp = malloc(sizeof(char) * (strlen(ln) + 1));
    strcpy(cp, ln);

    char *ag;
    char **ags = malloc(sizeof(char *));
    int k = 0;
    while ((ag = strtok(cp, " \t")) != NULL)
    {
        ags[k] = malloc(sizeof(char) * (strlen(ag) + 1));
        strcpy(ags[k], ag);
        ags = realloc(ags, sizeof(char *) * (++k + 1));
        cp = NULL;
    }
    ags[k] = NULL;
    return ags;
}

int log_details(char *filename)
{
    int f;
    if ((f = open(filename, O_CREAT | O_APPEND | O_WRONLY, 0755)) == -1)
    {
        fprintf(stderr, "Error: failed to open \"%s\"\n", filename);
        perror("open");
        exit(EXIT_FAILURE);
    }
    return f;
}









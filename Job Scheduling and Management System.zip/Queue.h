
// importing the thread library
#include <pthread.h>


//creating the job deatils

typedef struct j_details
{
    int j_id;
    char *command,*status;
    int exit_status;
    char *start_time, *end_time;
    char fileoutput[20],fileerr[20];
    pthread_t pid;

} j_details;

typedef struct job_q 
{
      int q_size,q_count;
      int start_index, end_index;
      j_details **jobbuffer;
} job_q; 

j_details CreateJob(char *command, int jobid);
void viewJobs(j_details *jd,int count_jobs,char *mode);

job_q *init_q(int n);
int insert_q(job_q *q, j_details *jd);
j_details *delete_q(job_q *q);
void destroy_q(job_q *q);


int get_l(char *s, int n);
int isSpace(char c);
char *l_s(char *s);
char *copy(char *s);
char *copynewline(char *s);
char *datetime_current();
char **arguments(char *line);
int log_details(char *fn);







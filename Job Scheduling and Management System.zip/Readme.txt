First run the make file will get the following output
gcc -Wall -lpthread -o mysched mysched.c Queue.c
run the program like below
 ./mysched 2
The concurrency details: 2
Enter Command> submit ls -l
Job Added 0 to  queue
Enter Command> submithistory
Job ID: 0
Thread ID: 139878825379392
Command: ls -l
Exit Status: 0
Start Time: Mon Apr 17 20:58:26 2023
Stop Time: Mon Apr 17 20:58:26 2023

Enter Command> 
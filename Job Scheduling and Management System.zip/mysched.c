#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>
#include <pthread.h>
#include "Queue.h"

#define LENGTH_JOBSQ 100
#define LENGTH_LINE 1000 
#define LENGTH_JOBS 1000

int concurrency;        
int currently_working_jobs;     
j_details jd[LENGTH_JOBS];
job_q *jq;

void manage_input()
{
    int k=0;             
    char line[LENGTH_LINE]; 
    char *keyword;           
    char *command;         

    //printf("Enter Command");

    while (printf("Enter Command> ") && get_l(line, LENGTH_LINE) != -1)
    {
        if ((keyword = strtok(copy(line), " \t\n\r\x0b\x0c")) != NULL)
        {
            if (strcmp(keyword, "submit") == 0)
            {
                if (k >= LENGTH_JOBS)
                    printf("job histor is full\n");
                else if (jq->q_count >= jq->q_size)
                    printf("job queue is full\n");
                else
                {
                    command = l_s(strstr(line, "submit") + 6);
                    jd[k] = CreateJob(command, k);
                    insert_q(jq, jd + k);
                    printf("Job Added %d to  queue\n", k++);
                }
            }
            else if (strcmp(keyword, "showjobs") == 0 || strcmp(keyword, "submithistory") == 0)
                viewJobs(jd,k,keyword);
        }
    }
    kill(0, SIGINT); 
}

void *cjob(void *arg)
{
    j_details *jdt;     
    char **args; 
    pid_t pid;  

    jdt = (j_details *)arg;

    ++currently_working_jobs;

    jdt->status = "working";
    jdt->start_time = datetime_current();

    pid = fork();
    if (pid == 0) 
    {
        dup2(log_details(jdt->fileoutput), STDOUT_FILENO);
        dup2(log_details(jdt->fileerr), STDERR_FILENO);
        args = arguments(jdt->command);
        execvp(args[0], args);
        fprintf(stderr, "Error: command execution failed  \"%s\"\n", args[0]);
        perror("execvp");
        exit(EXIT_FAILURE);
    }
    else if (pid > 0) 
    {
        waitpid(pid, &jdt->exit_status, WUNTRACED);
        jdt->status = "complete";
        jdt->end_time = datetime_current();

        if (!WIFEXITED(jdt->exit_status))
            fprintf(stderr, "Child process %d did not terminate normally!\n", pid);
    }
    else
    {
        fprintf(stderr, "Error: process fork failed\n");
        perror("fork");
        exit(EXIT_FAILURE);
    }

    --currently_working_jobs;
    return NULL;
}


void *cjobs(void *arg)
{
    j_details *jdt; 

    currently_working_jobs = 0;
    for (;;)
    {
        if (jq->q_count > 0 && currently_working_jobs < concurrency)
        {
            
            jdt = delete_q(jq);

            pthread_create(&jdt->pid, NULL, cjob, jdt);
            pthread_detach(jdt->pid);
        }
        sleep(1);
    }
    return NULL;
}




int main(int argc, char const *argv[])
{
    char *filenameerror;   
    pthread_t thread_id; 

    if (argc != 2)
    {
        printf("Usage: %s CONCURRENCY\n", argv[0]);
        exit(EXIT_SUCCESS);
    }

    concurrency = atoi(argv[1]);
    if (concurrency < 1)
        concurrency = 1;
    else if (concurrency > 8)
        concurrency = 8;

    printf("The concurrency details: %d\n", concurrency);

    filenameerror = malloc(sizeof(char) * (strlen(argv[0]) + 5));
    sprintf(filenameerror, "%s.err", argv[0]);
    dup2(log_details(filenameerror), STDERR_FILENO);

    jq = init_q(LENGTH_JOBSQ);

    pthread_create(&thread_id, NULL, cjobs, NULL);

    
    manage_input();

    exit(EXIT_SUCCESS);
    
}



